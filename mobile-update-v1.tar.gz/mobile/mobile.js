'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const speaker = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 4 5 9H2v6h3l6 5V4Z"/><path d="M15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/></svg>';
  const read = (key, fallback) => {try{return JSON.parse(localStorage.getItem(key)) ?? fallback;}catch{return fallback;}};
  const save = (key, value) => {try{localStorage.setItem(key, JSON.stringify(value));return true;}catch{return false;}};
  const prefs = read('wordspace.mobile.preferences.v1', {});
  const params = new URLSearchParams(location.search);
  let book = MOBILE_CATALOG[params.get('book')] ? params.get('book') : (MOBILE_CATALOG[prefs.book] ? prefs.book : 'ielts');
  let chapter = Number(params.get('list') || prefs[book]) || 1;
  let records = [], visible = [], selected = null, onlyMarked = false, request = 0;
  let activeAudio = null, audioButton = null, audioTimer = null, toastTimer = null;
  const cached = new Map(), loading = new Map();
  const markKey = () => book + '.wordMarks.v1';
  const marks = () => {const v=read(markKey(),[]);return new Set(Array.isArray(v)?v.filter(Number.isInteger):[]);};
  const chapterInfo = () => MOBILE_CATALOG[book].chapters.find(c => c.id === chapter);
  const audioPath = name => '../' + (book === 'ielts' ? 'ielts/' : '') + 'audio/' + name;
  const audioBtn = (name, label) => name ? `<button class="audio-button" data-audio="${esc(name)}" aria-label="${esc(label)}">${speaker}</button>` : '';
  function toast(message){clearTimeout(toastTimer);$('toast').textContent=message;$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,4000);}
  function stopAudio(){clearTimeout(audioTimer);if(activeAudio){activeAudio.pause();activeAudio.removeAttribute('src');activeAudio.load();activeAudio=null;}if(audioButton)audioButton.removeAttribute('aria-busy');audioButton=null;}
  function play(name, button){
    stopAudio();const audio=new Audio();activeAudio=audio;audioButton=button;
    button.setAttribute('aria-busy','true');audio.preload='auto';audio.src=audioPath(name);
    let started=false;
    const done=()=>{if(activeAudio!==audio)return;clearTimeout(audioTimer);button.removeAttribute('aria-busy');activeAudio=null;audioButton=null;};
    const fail=()=>{if(activeAudio!==audio)return;stopAudio();toast('音频暂时未加载，请检查网络后再点喇叭重试。');};
    audio.addEventListener('playing',()=>{started=true;clearTimeout(audioTimer);});
    audio.addEventListener('ended',done);audio.addEventListener('error',fail);
    audioTimer=setTimeout(()=>{if(!started)fail();},18000);
    audio.play().catch(fail);
  }
  function loadData(identity, list){
    const key=identity+':'+list;if(cached.has(key))return Promise.resolve(cached.get(key));if(loading.has(key))return loading.get(key);
    const promise=new Promise((resolve,reject)=>{
      const script=document.createElement('script');let finished=false;
      const timer=setTimeout(()=>finish(false),20000);
      const finish=ok=>{if(finished)return;finished=true;clearTimeout(timer);script.remove();loading.delete(key);if(ok&&cached.has(key))resolve(cached.get(key));else reject(new Error('load'));};
      script.src=`./data/${identity}-${list}.js?v=${MOBILE_CATALOG.version}`;
      script.onload=()=>finish(true);script.onerror=()=>finish(false);document.head.append(script);
    });loading.set(key,promise);return promise;
  }
  window.registerMobileWords=(identity,list,words)=>cached.set(identity+':'+list,words);
  function renderWords(){
    const marked=marks(), query=$('search').value.trim().toLocaleLowerCase();
    visible=records.filter(w=>(!onlyMarked||marked.has(w.id))&&(!query||(w.word+' '+w.meaningCN+' '+w.phonetic).toLocaleLowerCase().includes(query)));
    $('clearSearch').hidden=!query;
    $('count').textContent=visible.length===records.length?`${records.length} 个单词`:`${visible.length} / ${records.length} 个单词`;
    $('words').innerHTML=visible.map(w=>`<article class="word-card${marked.has(w.id)?' is-marked':''}" data-id="${w.id}"><button class="word-open" data-open="${w.id}" aria-label="查看 ${esc(w.word)} 的释义与例句"><span class="word-line"><span class="word-name" lang="en">${esc(w.word)}</span>${w.tag?`<span class="tag${w.tag==='核心'?' core':''}">${esc(w.tag)}</span>`:''}</span><span class="phonetic" lang="en-US">${esc(w.phonetic)}</span><span class="meaning">${esc(w.pos)} ${esc(w.meaningCN)}</span></button><div class="audio-stack">${audioBtn(w.audio,'朗读 '+w.word)}<span class="word-index" aria-label="本模块第 ${w.ordinal} 个词">${w.ordinal}</span></div></article>`).join('');
    $('state').textContent=visible.length?'':onlyMarked?'当前模块还没有符合条件的标红单词。':'没有找到这个单词，试试其他词或切换模块。';
  }
  async function selectModule(identity,list){
    const version=++request;stopAudio();if($('detail').open)$('detail').close();book=identity;chapter=list;
    if(!chapterInfo())chapter=MOBILE_CATALOG[book].chapters[0].id;
    prefs.book=book;prefs[book]=chapter;save('wordspace.mobile.preferences.v1',prefs);
    try{const url=new URL(location.href);url.searchParams.set('book',book);url.searchParams.set('list',chapter);history.replaceState(null,'',url);}catch{}
    document.querySelectorAll('[data-book]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.book===book)));
    $('moduleSelect').innerHTML=MOBILE_CATALOG[book].chapters.map(c=>`<option value="${c.id}"${c.id===chapter?' selected':''}>${esc(c.title)} · ${c.count} 词</option>`).join('');
    $('moduleTitle').textContent=chapterInfo().title;$('count').textContent='';$('search').value='';$('clearSearch').hidden=true;$('words').replaceChildren();$('retry').hidden=true;$('state').textContent='正在加载单词…';records=[];visible=[];window.scrollTo(0,0);
    try{const words=await loadData(book,chapter);if(version!==request)return;records=words;renderWords();}
    catch{if(version!==request)return;$('state').textContent='模块暂时没有加载成功，请检查网络后重试。';$('retry').hidden=false;}
  }
  function renderDetail(){
    const w=visible.find(w=>w.id===selected);if(!w)return;
    const marked=marks().has(w.id),index=visible.indexOf(w);
    $('detailModule').textContent=`${chapterInfo().title} · ${w.ordinal}`;
    const parts=(kind,title)=>w[kind]?.length?`<section class="part"><h3>${title}</h3>${w[kind].map(p=>`<div class="example"><div class="example-row"><p lang="en-US">${esc(p.en)}</p>${audioBtn(p.audio,'朗读英文'+title)}</div>${p.cn?`<p class="cn">${esc(p.cn)}</p>`:''}</div>`).join('')}</section>`:'';
    $('detailBody').innerHTML=`<div class="detail-heading"><h2 id="detailWord" lang="en">${esc(w.word)}</h2>${audioBtn(w.audio,'朗读 '+w.word)}</div><div class="phonetic" lang="en-US">美 ${esc(w.phonetic)}</div>${w.definitions.map(d=>`<p class="definition">${esc(d)}</p>`).join('')}<button id="toggleMark" class="mark-button" aria-pressed="${marked}">${marked?'已标红 · 点击取消':'标红这个单词'}</button>${parts('examples','例句')}${parts('phrases','词组与搭配')}${w.root?`<section class="part"><h3>记忆提示</h3><p class="memory">${esc(w.root)}</p></section>`:''}`;
    $('previous').disabled=index===0;$('next').disabled=index===visible.length-1;$('detailBody').scrollTop=0;
  }
  function openDetail(id){selected=id;renderDetail();if(!$('detail').open){$('detail').showModal();document.body.classList.add('detail-open');}}
  $('words').addEventListener('click',e=>{const a=e.target.closest('[data-audio]');if(a){play(a.dataset.audio,a);return;}const b=e.target.closest('[data-open]');if(b)openDetail(Number(b.dataset.open));});
  $('detailBody').addEventListener('click',e=>{
    const a=e.target.closest('[data-audio]');if(a){play(a.dataset.audio,a);return;}
    if(e.target.closest('#toggleMark')){
      const marked=marks(),wasMarked=marked.has(selected);if(wasMarked)marked.delete(selected);else marked.add(selected);
      if(!save(markKey(),[...marked])){toast('当前浏览器无法保存标红，请使用普通浏览模式。');return;}
      // Keep the current detail available when it leaves the marked-only list.
      const w=visible.find(w=>w.id===selected);renderWords();
      if(w&&!visible.some(v=>v.id===selected)){stopAudio();$('detail').close();}else renderDetail();
    }
  });
  $('previous').addEventListener('click',()=>move(-1));$('next').addEventListener('click',()=>move(1));
  function move(step){const index=visible.findIndex(w=>w.id===selected),w=visible[index+step];if(w){stopAudio();selected=w.id;renderDetail();}}
  $('closeDetail').addEventListener('click',()=>$('detail').close());
  $('detail').addEventListener('close',()=>{stopAudio();document.body.classList.remove('detail-open');});
  $('detail').addEventListener('click',e=>{if(e.target===$('detail')){const r=$('detail').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)$('detail').close();}});
  document.querySelectorAll('[data-book]').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.book!==book)selectModule(b.dataset.book,Number(prefs[b.dataset.book])||1);}));
  $('moduleSelect').addEventListener('change',e=>selectModule(book,Number(e.target.value)));
  $('search').addEventListener('input',renderWords);$('clearSearch').addEventListener('click',()=>{$('search').value='';renderWords();$('search').focus();});
  $('markedOnly').addEventListener('click',()=>{onlyMarked=!onlyMarked;$('markedOnly').setAttribute('aria-pressed',String(onlyMarked));renderWords();});
  $('retry').addEventListener('click',()=>selectModule(book,chapter));
  window.addEventListener('storage',e=>{if(e.key===markKey()&&records.length){renderWords();if($('detail').open){if(visible.some(w=>w.id===selected))renderDetail();else $('detail').close();}}});
  window.addEventListener('pagehide',stopAudio);
  selectModule(book,chapter);
})();
