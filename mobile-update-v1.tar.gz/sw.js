const CACHE="wordspace-c7e3a80aae4c",SHELL=["./index.html", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png", "./apple-touch-icon.png", "./favicon.svg", "./study/index.html", "./study/index.html?v=25de0b6da601", "./study/manifest.json", "./ielts/index.html", "./ielts/study/index.html", "./ielts/study/index.html?v=d46a97552e9c", "./ielts/study/manifest.json"],MEDIA="cet4-study-audio-f7af6a0ae5373362",IELTS_MEDIA="ielts-study-audio-ca81d1e404ff9590";
const INDEX=new URL('./index.html',self.location.href).href,STUDY=new URL('./study/index.html',self.location.href).href;
const IELTS_INDEX=new URL('./ielts/index.html',self.location.href).href,IELTS_STUDY=new URL('./ielts/study/index.html',self.location.href).href;
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting())));
async function activate(){
 const names=await caches.keys(),shell=await caches.open(CACHE);
 // Keep previously downloaded practice recordings when the app shell changes.
 for(const name of names.filter(name=>name.startsWith('wordspace-')&&name!==CACHE&&!name.startsWith('wordspace-mobile-'))){
  const old=await caches.open(name);
  for(const path of ['./audio-pack.json','./ielts/audio-pack.json']){
   const key=new URL(path,self.location.href).href;
   if(!await shell.match(key)){const response=await old.match(key);if(response)await shell.put(key,response);}
  }
 }
 await Promise.all(names.filter(name=>(name.startsWith('wordspace-')&&name!==CACHE&&!name.startsWith('wordspace-mobile-'))||((name.startsWith('cet4-study-audio-')||name.startsWith('ielts-study-audio-'))&&name!==MEDIA&&name!==IELTS_MEDIA)).map(name=>caches.delete(name)));
 await self.clients.claim();
}
self.addEventListener('activate',event=>event.waitUntil(activate()));
const MOBILE_ROOT=new URL('./mobile/',self.location.href).href;
async function mobileNavigation(request,event){
 const cache=await caches.open('wordspace-mobile-v1');
 try{const response=await fetch(request);if(response.ok)event.waitUntil(cache.put(new Request(MOBILE_ROOT+'index.html'),response.clone()));return response;}
 catch(error){const cached=await cache.match(MOBILE_ROOT+'index.html');if(cached)return cached;throw error;}
}
async function navigation(request,url,event){
 if(url.pathname.startsWith(new URL(MOBILE_ROOT).pathname))return mobileNavigation(request,event);
 const key=url.pathname===new URL(STUDY).pathname?STUDY:url.pathname===new URL(IELTS_STUDY).pathname?IELTS_STUDY:url.pathname.startsWith(new URL('./ielts/',self.location.href).pathname)?IELTS_INDEX:INDEX;
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),4500);
 try{const response=await fetch(request,{signal:controller.signal});if(response.ok){const copy=response.clone();event.waitUntil(caches.open(CACHE).then(cache=>cache.put(key,copy)));return response;}return await caches.match(key)||response;}
 catch(error){const hit=await caches.match(key);if(hit)return hit;throw error;}
 finally{clearTimeout(timeout);}
}
async function media(request,event){
 const cache=await caches.open(new URL(request.url).pathname.includes('/ielts/audio/')?IELTS_MEDIA:MEDIA),key=request.url,hit=await cache.match(key);
 if(!hit){const response=await fetch(request);if(response.status===200)event.waitUntil(cache.put(key,response.clone()));return response;}
 const range=request.headers.get('Range');if(!range)return hit;
 const match=/^bytes=(\d*)-(\d*)$/.exec(range);if(!match)return hit;
 const body=await hit.arrayBuffer(),size=body.byteLength;
 let start=match[1]?Number(match[1]):Math.max(0,size-Number(match[2])),end=match[1]?(match[2]?Number(match[2]):size-1):size-1;
 end=Math.min(end,size-1);
 if(start>=size||start>end)return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+size}});
 const headers=new Headers(hit.headers);headers.set('Content-Range',`bytes ${start}-${end}/${size}`);headers.set('Content-Length',String(end-start+1));headers.set('Accept-Ranges','bytes');
 return new Response(body.slice(start,end+1),{status:206,headers});
}
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);if(request.method!=='GET'||url.origin!==self.location.origin)return;
 if(request.mode==='navigate')event.respondWith(navigation(request,url,event));
 else if(url.pathname.startsWith(new URL(MOBILE_ROOT).pathname))event.respondWith(caches.open('wordspace-mobile-v1').then(async cache=>{const hit=await cache.match(request);if(hit)return hit;const response=await fetch(request);if(response.ok)event.waitUntil(cache.put(request,response.clone()));return response;}));
 else if(request.cache==='reload')event.respondWith(fetch(request));
 else if(/\/audio\/[a-f0-9]{24}\.mp3$/.test(url.pathname))event.respondWith(media(request,event));
 else event.respondWith(caches.open(CACHE).then(cache=>cache.match(request)).then(hit=>hit||fetch(request)));
});
